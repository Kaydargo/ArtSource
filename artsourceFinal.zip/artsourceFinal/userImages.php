<!DOCTYPE html>
<html lang="en">

  <head>
        <title>User Images</title>
<?php include_once('includes/headlinks.php'); ?>
  </head>

  <body>

    <?php                session_start();
          require_once('includes/database.php');
          require_once('includes/header.php');

                $userID = filter_input(INPUT_GET, "userID");
                
    $queryImages = "SELECT * FROM image WHERE userID=$userID";
   
    $statement1 = $db->prepare($queryImages);
    $statement1->execute();
    $images = $statement1->fetchAll();
    $statement1->closeCursor();
    ?>

      <div class="panel panel-default"><br><br>   
                <h2>Artists Work</h2>
                <div class="panel-body">
                    <div class="row">
       <?php
 foreach($images as $image): 
     ?>
                        
                        </br> 
                        <div class="col-md-2">  
                            <a href="profile.php?userID=<?php echo $image['userID']?>"><?= ($image['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:40px' src='images/{$image['image']}'/>" : "") ?></a>
<!--                                <?= ($image['description'] <> "" ? $image['description'] : "\t") ?> <br>-->

                                                  
                       </div> 
  <?php endforeach; ?>    
                    </div>
                </div>
      </div><br>
    <?php include_once 'includes/footer.php'; ?>

  </body>
</html>