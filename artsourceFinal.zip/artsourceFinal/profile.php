<!DOCTYPE html>
<html>
<head>
    <title>View Profile</title>
    
    <?php include_once'includes/headlinks.php';?>
    <link href="css/popupcontact.css" rel="stylesheet" type="text/css"/>
    <script src="jQuery/artsource.js" type="text/javascript"></script>
    
      <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="jQuery/popupcontact.js" type="text/javascript"></script>
</head>
<body>
    <?php                session_start();
          require_once('includes/database.php');
         require_once('includes/header.php');

    ?>
    
             <?php 
require_once('includes/database.php');

    $userID = filter_input(INPUT_GET, 'userID');

    $queryUser = "SELECT * FROM users WHERE userID = $userID"; 
    $statement2 = $db->prepare($queryUser);
    $statement2->execute();
    $users = $statement2->fetchAll();
    $statement2->closeCursor();
    
    ?>
    
                 <?php 
require_once('includes/database.php');

//Selects all images, their id and userid with the tag animated
    $queryImages = "SELECT * FROM image WHERE userID = $userID LIMIT 6 "; 
    $statement3 = $db->prepare($queryImages);
    $statement3->execute();
    $images = $statement3->fetchAll();
    $statement3->closeCursor();
    ?>

<div id="profile">
        <?php foreach ($users as $user) : ?>
        <tr>
                        

        </tr><br><br>
        
        <br>

</div>


<div class="container">

        <div class="col-md-12 col-md-12 col-md-10 col-lg-10 col-md-offset-2 col-sm-offset-5 col-md-offset-15 col-lg-offset-15 toppad" >
          <div class="panel panel-info">
            <div class="panel-heading">
              <h1 class="panel-title"><?php echo $user['username']; ?></h1>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td>Average Price:</td>
                        <td>€<?php echo $user['avgPrice']; ?></td>
                      </tr>
                      
                      <tr>
                        <td>Location:</td>
                        <td><?php echo $user['location']; ?></td>
                      </tr>
                      
                      <tr>
                        <td>Speciality: </td>
                        <td><?php echo $user['speciality']; ?></td>
                      </tr>
                   
                             <tr>
                        <td>Contact: </td>
                        <td><?php echo $user['email']; ?>
                         <div class="contact-container">  
                            <ul class="actions">
                                <a href="#" id="contact" class="button big"><button class ="contact-button">Contact</button></a>
                            </ul>
                         </div>
                        </td>
                      </tr>
                    
                         <div class="cd-popup contact" role="alert">
                             
       <form id="contactform" name="contactForm" class="contact-form" method="POST" action="contact_query.php">
        <div class="cd-popup-container" style="">
      <h3>Send message to Artist</h3>
      <hr><br>
        <a href="" class="cd-popup-close cd-close-button">
          <i class="fa fa-times" style="pointer-events:none;"></i>
        </a>
      
      
      <div class="name">
          <label for="name" class="contact-label">Name</label><br>
          <input type="text" id="firstname" name="firstname" class="form-control"/><br>
      </div><br>
      
      <div class="recipient">
          <input type="hidden" name="recipientID" value="<?php echo $userID ?> " class="form-control" >
      </div><br>
      
      <div class="email">
          <label for="email" class="contact-label">Email</label><br>
          <input type="text" id="email" name="email" class="form-control" /><br>
      </div><br>
      
      <div class="message">
          <label for="message" class="contact-label">Message</label><br>
          <textarea id="message" name="message" class=" form-control"></textarea><br>
      </div>
      <br><br>
      
      <div class="submit">        
          <input type="submit" value="Go!" name="submit" class="edit-submit">
      </div>
      
    </div>
  </form>
</div>   
                    
                    
                         <tr>
                        <td>About Me:</td>
                        <td><?php echo $user['bio']; ?></td>
                      </tr>
                     
                    </tbody>
                  </table>
                  
                </div>
                <div class="col-lg-3 col-lg-3 " align="right"> <img alt="User Pic" src="images/<?php echo $user['profilePic']; ?>" class="img-square img-responsive"> </div>
              </div>
                     
                   
                  
                </div>
              
              </div>
                 
            </div>

          </div>
        </div>
      </div>
    </div>   
    
    
    
    <h2>Other Work</h2>
    <hr class="divline">
    <a href="userImages.php?userID=<?php echo $user['userID']?>"><button class="see-more-portfolio">See More +</button></a>
    <?php endforeach; ?>
      <div class="panel panel-default"><br><br>   
                  <div class="panel-body">
                    <div class="row">
 <?php
 foreach($images as $image): 
     ?>
                        </br> 
                        <div class="col-md-2">  
                         <?= ($image['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:40px' src='images/{$image['image']}'/>" : "") ?>          
                                                  
                       </div> 
  <?php endforeach; ?>      
            <!-- End of Foreach Statement -->
            
        </div>
       </div>
     </div>
    

       
    

    
    <br>      
      
    
     <?php include_once 'includes/footer.php'; ?>
</body>
</html>