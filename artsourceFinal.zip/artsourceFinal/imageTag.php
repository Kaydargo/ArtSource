<!DOCTYPE html>
<html lang="en">

  <head>
        <title>Image Tags</title>
<?php include_once('includes/headlinks.php'); ?>
  </head>

  <body>

    <?php                session_start();
          require_once('includes/database.php');
          require_once('includes/header.php');
?>
                  <div class="col-md-12">
                
                      <?php 
                      require_once('includes/database.php');
                      require ('gallaryQueries.php');
                
                $tag = filter_input(INPUT_GET, "tag");
                
                
                
                if ($tag !="") {
    $queryDigital = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='$tag' "; 
                }
                else {
                    $queryDigital = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID"; 
                }
    $statement2 = $db->prepare($queryDigital);
    $statement2->execute();
    $imageTags = $statement2->fetchAll();
    $statement2->closeCursor();
    ?><br>
                      <h2><?php echo $tag ?></h2><br>
    <a href="gallery.php"><button class="gallery-back-button">Back</button></a>
            <!--/.Panel -->
            </br>
            <div class="container">
                
                
            <div class="panel panel-default"><br><br>   
                  <div class="panel-body">
                    <div class="row">

                        <?php
       
        foreach($imageTags as $imageTag):  
         ?><div class="col-md-3">
                  <a class="thumbnail" href="profile.php?userID=<?php echo $imageTag['userID'] ?>">
<?= ($imageTag['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:10px; margin-bottom:10px' src='images/{$imageTag['image']}'/>" : "") ?>        
                         </a>                         
 </div> 
  <?php endforeach; ?>      
            <!-- End of Foreach Statement -->
            
        </div>
       </div>
     </div>
           
            
            
            
            
    <br>
            </div>
          <?php include_once 'includes/footer.php'; ?>
  </body>
</html>