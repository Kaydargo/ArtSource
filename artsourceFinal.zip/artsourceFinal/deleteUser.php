<?php
require_once('includes/database.php');

// Get IDs
$userID = filter_input(INPUT_POST, 'userID', FILTER_VALIDATE_INT);

// Delete the user from the database
if ($userID != false) {
    $query = "DELETE FROM users
              WHERE userID = :userID";
    $statement = $db->prepare($query);
    $statement->bindValue(':userID', $userID);
    $statement->execute();
    $statement->closeCursor();
}

// display the admin page
include('admin.php');
?>