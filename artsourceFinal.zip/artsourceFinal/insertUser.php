<?php
// Get the product data
$firstname = filter_input(INPUT_POST, 'firstname');
$lastname = filter_input(INPUT_POST, 'lastname');
$username = filter_input(INPUT_POST, 'username');
$email = filter_input(INPUT_POST, 'email');
$password = filter_input(INPUT_POST, 'password');
$location = filter_input(INPUT_POST, 'location');
$type = filter_input(INPUT_POST, 'type');
$dob =  filter_input(INPUT_POST, 'dob');
$avgPrice =  filter_input(INPUT_POST, 'avgPrice', FILTER_VALIDATE_FLOAT);

// Validate inputs
if ($firstname == null || $username == null || $lastname == null || $email == null|| $password == null || $location == null || $type == null || $type == null || empty($dob)) {
    $error = "Invalid user data. Check all fields and try again.";
    include('error.php');
} else {
    require_once('includes/database.php');

    // Add the product to the database 
    $query = "INSERT INTO users
                 (firstname, lastname, username, email, password, location, type, dob, avgPrice)
              VALUES
                 (:firstname, :lastname, :username, :email, :password, :location, :type, :dob, :avgPrice)";
    $statement = $db->prepare($query);
    $statement->bindValue(':firstname', $firstname);
    $statement->bindValue(':lastname', $lastname);
    $statement->bindValue(':username', $username);
    $statement->bindValue(':email', $email);
    $statement->bindValue(':password', $password);
    $statement->bindValue(':location', $location);
    $statement->bindValue(':type', $type);
    $statement->bindValue(':dob', $dob);
    $statement->bindValue(':avgPrice', $avgPrice);
    $statement->execute();
    $statement->closeCursor();

    // Display the Product List page
    include('index.php');
}
?>