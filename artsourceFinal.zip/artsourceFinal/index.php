<!DOCTYPE html>
<html lang="en">

    <head>
        <link href="css/lightboxStyle.css" rel="stylesheet" type="text/css"/>
        <?php include_once('includes/headlinks.php'); ?>

    </head>

    <body>


        <!-- Page Content --> 
        <div class="image-aboutus-banner"style="margin-top:70px">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="lg-text">By Artists - For Artists</h1>
                        <p>ArtSource aims to bring artists and clients together in a easy to use community environment.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <?php

          require_once('includes/database.php');
          require_once('includes/header.php');
?>

            <?php
            $queryImages = "SELECT image.image, image.imgID, image.description, image.userID, users.userID FROM image, users WHERE image.userID = users.userID AND users.accountCreation < (DATE_ADD(NOW(), INTERVAL 1 YEAR))";

            $statement1 = $db->prepare($queryImages);
            $statement1->execute();
            $images = $statement1->fetchAll();
            $statement1->closeCursor();
            ?>
            <!--/.Panel -->

            <div class="panel panel-default"><br><br>   
                <h2>New Artists</h2>
                <div class="panel-body">
                    <div class="row">
                        <?php
                        foreach ($images as $image):
                            ?>
                            <div class="col-md-2">  
                                <a class="lightbox" href="#<?php echo $image['imgID'] ?>">
                                    <?= ($image['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:40px' src='images/{$image['image']}'/>" : "") ?>
                                </a>
                            </div>               

                        <?php endforeach; ?>   
                        <!-- End of Foreach Statement -->
                        <?php
                        foreach ($images as $image):
                            ?>              
                            <div class="lightbox-target" id="<?php echo $image['imgID'] ?>">

                                <a href="profile.php?userID=<?php echo $image['userID'] ?>" ><button class="w3-button w3-black w3-padding-large w3-large" id="view">View Profile</button></a>

                                <?= ($image['image'] <> " " ? "<img src='images/{$image['image']}'/>" : "") ?>
                                <a class="lightbox-close" href="#"></a>
                            </div>                      

                        <?php endforeach; ?>   
                        <!-- End of Foreach Statement -->

                    </div>
                </div>
            </div>
            <!--/.row1-collapse -->  
        </div>


        <br>



        <?php include_once 'includes/footer.php'; ?>

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    </body>

</html>
