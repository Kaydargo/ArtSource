<?php 
require_once('includes/database.php');


    $queryDigital = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='digital' LIMIT 4"; 
    $statement2 = $db->prepare($queryDigital);
    $statement2->execute();
    $digitals = $statement2->fetchAll();
    $statement2->closeCursor();
    
    $queryDigital1 = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='digital' LIMIT 4,8"; 
    $statement2 = $db->prepare($queryDigital1);
    $statement2->execute();
    $digitals1 = $statement2->fetchAll();
    $statement2->closeCursor();
    
     $queryDigital2 = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='digital' LIMIT 8,12"; 
    $statement2 = $db->prepare($queryDigital2);
    $statement2->execute();
    $digitals2 = $statement2->fetchAll();
    $statement2->closeCursor();
    ?>
      
       <?php
    $queryPaint1 = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='paint' LIMIT 4"; 
    $statement3 = $db->prepare($queryPaint1);
    $statement3->execute();
    $paintings1 = $statement3->fetchAll();
    $statement3->closeCursor();
    
    $queryPaint2 = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='paint' LIMIT 4,8"; 
    $statement3 = $db->prepare($queryPaint2);
    $statement3->execute();
    $paintings2 = $statement3->fetchAll();
    $statement3->closeCursor();
    
    $queryPaint3 = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='paint' LIMIT 8,12"; 
    $statement3 = $db->prepare($queryPaint3);
    $statement3->execute();
    $paintings3 = $statement3->fetchAll();
    $statement3->closeCursor();
    ?>
      
       <?php
    $queryColour = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='colour' LIMIT 4"; 
    $statement4 = $db->prepare($queryColour);
    $statement4->execute();
    $colourings = $statement4->fetchAll();
    $statement4->closeCursor();
    
    $queryColour1 = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='colour' LIMIT 4,8"; 
    $statement4 = $db->prepare($queryColour1);
    $statement4->execute();
    $colourings1 = $statement4->fetchAll();
    $statement4->closeCursor();
    
    $queryColour2 = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='colour' LIMIT 8,12"; 
    $statement4 = $db->prepare($queryColour2);
    $statement4->execute();
    $colourings2 = $statement4->fetchAll();
    $statement4->closeCursor();
    ?>
      
        <?php
    $queryPencil = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='pencil' LIMIT 4"; 
    $statement5 = $db->prepare($queryPencil);
    $statement5->execute();
    $sketches = $statement5->fetchAll();
    $statement5->closeCursor();
    
    $queryPencil1 = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='pencil' LIMIT 4,8"; 
    $statement5 = $db->prepare($queryPencil1);
    $statement5->execute();
    $sketches1 = $statement5->fetchAll();
    $statement5->closeCursor();
    
    $queryPencil2 = "SELECT image.image, image.userID, users.userID FROM image, users WHERE image.userID = users.userID     AND tag ='pencil' LIMIT 8,12"; 
    $statement5 = $db->prepare($queryPencil2);
    $statement5->execute();
    $sketches2 = $statement5->fetchAll();
    $statement5->closeCursor();
    ?>