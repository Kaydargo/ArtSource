-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2018 at 12:39 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `artsource`
--

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `imgID` int(3) NOT NULL,
  `userID` int(3) NOT NULL,
  `image` varchar(30) NOT NULL,
  `title` varchar(20) NOT NULL,
  `description` varchar(30) DEFAULT NULL,
  `tag` varchar(20) NOT NULL,
  `nsfw` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`imgID`, `userID`, `image`, `title`, `description`, `tag`, `nsfw`) VALUES
(1, 1, 'ivyGirl.jpg', '', 'Green ivy girl', 'digital', ''),
(2, 1, 'catRainbow.jpg', '', 'Cat with rainbow form mouth', 'colour', ''),
(3, 1, 'giraffe.jpg', '', 'Giraffe with tongue ', 'colour', ''),
(4, 1, 'fox.jpg', '', 'Fox with bow and glasses ', 'colour', ''),
(5, 1, 'bella.jpg', '', 'Bella ', 'colour', ''),
(6, 2, 'mushroom.jpg', '', 'Mushroom ', 'digital', ''),
(7, 2, 'flower.jpg', '', 'Flower ', 'digital', ''),
(8, 1, 'lion.jpg', '', 'Head of a lion', 'paint', 'NO'),
(9, 2, 'girlWhiteHair.jpg', '', 'Girl with white hair, peace', 'digital', 'NO'),
(10, 1, 'hummingBird.jpg', '', 'Flying hummingbird', 'paint', 'NO'),
(11, 1, 'headExplode.jpg', '', 'Head exploded into pieces', 'paint', 'NO'),
(12, 2, 'twoWolves.jpg', '', 'White and Black wolve pressing', 'colour', 'NO'),
(13, 3, 'war.jpg', '', 'Military men in gas masks, dys', 'digital', 'NO'),
(14, 3, 'floatingHead.jpg', '', 'Statue head floating', 'digital', 'NO'),
(15, 3, 'girlGun.jpg', '', 'Girl seated with a gun', 'digital', 'NO'),
(16, 1, 'lionPaint.jpg', '', 'Painted lions head', 'paint', 'NO'),
(17, 3, 'warMachine.jpeg', '', 'War machine surveying land', 'digital', 'NO'),
(18, 3, 'digitalOld.jpg', '', 'Tri-coloured girl animation', 'digital', 'NO'),
(19, 2, 'girlColour.jpg', '', 'Multi-coloured girl with desse', 'colour', 'NO'),
(20, 3, 'binding.jpg', '', 'Binding of Isacc', 'digital', 'NO'),
(21, 2, 'danceStick.jpg', '', 'Tall needle girl dancing', 'paint', 'NO'),
(22, 3, 'witch.jpg', '', 'Female fire conjourer', 'digital', 'NO'),
(23, 3, 'floatingCity.jpg', '', 'Floating city above clouds', 'digital', 'NO'),
(24, 1, 'paintedTown.jpg', '', 'Town created with shapes and p', 'paint', 'NO'),
(25, 3, 'adventurerForest.jpg', '', 'Adventurer exploring lite up f', 'digital', 'NO'),
(26, 3, 'girlKey.jpg', '', 'Girl holding key to herself', 'animation', 'NO'),
(27, 1, 'dishonored.jpg', '', 'Pencil sketch of dishonored ch', 'pencil', 'NO'),
(28, 1, 'baird.jpg', '', 'baird wielding gun from gears ', 'pencil', 'NO'),
(29, 3, 'witcher.jpg', '', 'Witcher 3 battling enemies', 'digital', 'NO'),
(30, 3, 'elephant.jpg', '', 'Elephant with paint splatter', 'paint', 'NO'),
(31, 1, 'scratch.jpg', '', 'Sketch of scratch from ice age', 'pencil', 'NO'),
(32, 1, 'girl.jpeg', '', 'This is a new image to be adde', 'Digital', 'Yes'),
(35, 2, 'eagle.jpg', '', 'Eagle drawing', 'pencil', 'No'),
(37, 2, 'gollum.jpg', '', 'Gollum Lord of the Rings', 'pencil', 'No'),
(38, 2, 'catButterfly.jpg', '', 'Cat up close to butterfly', 'pencil', 'No'),
(39, 2, 'sonic.jpg', '', 'Sonic the Hedgehog', 'pencil', 'No'),
(40, 2, 'wonderWoman.jpg', '', 'Wonder woman with sword', 'pencil', 'No'),
(41, 2, 'rose.jpg', '', 'Rose', 'pencil', 'No'),
(42, 2, 'cabin.png', '', 'Cabin in the woods', 'pencil', 'No'),
(43, 2, 'dice.jpg', '', 'Dice dropped in water', 'pencil', 'No'),
(44, 2, 'naruto.jpg', '', 'Naruto', 'pencil', 'No'),
(45, 2, 'jackSparrow.jpg', '', 'Jack Sparrow looking down', 'pencil', 'No'),
(46, 2, 'eyeFlower.jpg', '', 'Eye with flower eyelashes', 'pencil', 'No'),
(47, 2, 'harleyQuinn.jpg', '', 'Harley Quinn with bat', 'pencil', 'No'),
(48, 1, 'ireland.jpg', '', 'Ireland paint splatter', 'paint', 'No'),
(49, 1, 'cityStreet.jpg', '', 'City street landscape', 'paint', 'No'),
(50, 1, 'girlCar.jpg', '', 'Girl laying on hood of car', 'paint', 'No'),
(51, 1, 'chameleon.jpg', '', 'Chameleon on branch', 'paint', 'No'),
(52, 1, 'girlSwing.jpg', '', 'Little girl on swing ', 'paint', 'No'),
(53, 1, 'loveBirds.jpg', '', 'Love birds perched on branches', 'colour', 'No'),
(54, 1, 'fish.jpg', '', 'Two blue fish', 'colour', 'No'),
(55, 1, 'church.jpg', '', 'Church in the forest', 'colour', 'No'),
(56, 1, 'peacock.jpg', '', 'Peacock', 'colour', 'No'),
(57, 1, 'incredibleHulk.jpg', '', 'Incredible Hulk', 'colour', 'No'),
(58, 1, 'captainAmerica.jpg', '', 'Captain America with shield', 'colour', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `messageID` int(11) NOT NULL,
  `userID` int(3) NOT NULL,
  `RecipientID` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `message` varchar(30) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `image` int(30) DEFAULT NULL,
  `messageTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`messageID`, `userID`, `RecipientID`, `firstname`, `email`, `message`, `subject`, `image`, `messageTime`) VALUES
(7, 1, 0, 'Kayleigh', 'Kayleigh@me.com', 'testsetset', 'account', NULL, '2018-04-19 14:28:02'),
(10, 1, 1, 'Orlaith', 'hello@gmail.com', 'This is a tester ', NULL, NULL, '2018-04-25 20:08:45'),
(13, 1, 1, 'Kayleigh', 'Kayleigh@me.com', 'Please work', NULL, NULL, '2018-04-25 20:22:57'),
(14, 1, 1, 'Kayleigh', 'gostar@gmail.com', 'Can I please have a quote for ', NULL, NULL, '2018-04-25 20:24:21'),
(17, 1, 2, 'Frodo', 'Frodo@gmail.com', 'Could you please sketch me a d', NULL, NULL, '2018-04-25 22:33:11');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderID` int(3) NOT NULL,
  `orderDate` date NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `userID` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderID`, `orderDate`, `price`, `userID`) VALUES
(1, '2017-01-01', '20.00', 1),
(2, '2017-01-01', '15.00', 2),
(3, '2017-01-01', '35.00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(3) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `profilePic` varchar(200) DEFAULT NULL,
  `type` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `location` varchar(30) DEFAULT NULL,
  `dob` date NOT NULL,
  `avgPrice` int(5) DEFAULT NULL,
  `speciality` varchar(30) DEFAULT NULL,
  `bio` varchar(200) DEFAULT NULL,
  `accountCreation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `firstname`, `lastname`, `username`, `profilePic`, `type`, `email`, `password`, `location`, `dob`, `avgPrice`, `speciality`, `bio`, `accountCreation`) VALUES
(1, 'Kayleigh  ', 'Hoey', 'Kayleigh', 'images.png', 'Artist', 'Kay@gmail.com', 'Kaypass', 'Ardee', '2018-04-18', 16, 'Colouring', 'My name is Kayleigh, I like to colour in pictures of cats', '2018-04-25 22:30:10'),
(2, 'Orlaith', 'Hanlon', 'Orlaith', 'john.jpg', 'User', 'Orlaith@gmail.com', 'Orlaithpass', 'Dundalk', '1994-04-05', 12, 'painting', NULL, '2018-04-25 13:04:50'),
(3, 'Niamh', 'Mooney', 'Niamh', 'girlGun.jpg', 'Artist', 'Niamh@gmail.com', 'Niamhpass', 'Drogheda', '1992-05-05', 25, 'digital', NULL, '2018-04-25 22:31:22'),
(4, 'Kayleigh', 'Hoey', 'root', '', 'Admin', 'Kayleigh@gmail.com', 'admin', 'house', '2018-04-26', NULL, NULL, NULL, '2018-04-24 17:28:59'),
(12, 'Kayleigh', 'Cena', 'stonerMan', NULL, 'User', 'Kayleigh@gmail.com', 'ass', 'fdsf', '2018-04-20', 0, NULL, NULL, '2018-04-25 16:48:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`imgID`),
  ADD KEY `fk_image` (`userID`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`messageID`),
  ADD KEY `fk_message` (`userID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `fk_orders` (`userID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `imgID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `messageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `fk_image` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `fk_message` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
