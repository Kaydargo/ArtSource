<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Logout</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/thumbnail-gallery.css" rel="stylesheet">

</head>
<body> <p>You have been successfully logged out</p> </body>
</body>
</html>
    <?php
session_start();
session_destroy();
header('Location: login.php');
?>
