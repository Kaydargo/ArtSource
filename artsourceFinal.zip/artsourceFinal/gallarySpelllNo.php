<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Artsource</title>

     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <!-- Custom styles for this template -->
    <link href="css/thumbnail-gallery.css" rel="stylesheet">
    <link href="css/stylesheet.css" rel="stylesheet" type="text/css"/>   
    <?php include_once 'includes/font.php'; ?>

  </head>

  <body>

    <?php include_once 'includes/header.php'; ?>
      
             <?php 
require_once('includes/database.php');

//Selects all images, their id and userid with the tag animated
require('gallaryQueries.php');
    ?>
    <!-- Page Content -->
    <br><br>
    <h2 class="gallery-header">Gallery</h2>
    
    
    
    <a href="#digitalImages" class="gallery-nav-links gallery-nav-left"> Digital</a>
    <a href="#paintImages" class="gallery-nav-links"> Paintings</a>
    <a href="#colourImages" class="gallery-nav-links"> Colourings</a>
    <a href="#pencilImages" class="gallery-nav-links gallery-nav-right"> Pencil</a>
    
    <br><br>
    <hr class="divline"><hr class="divline">
    <br><br><br>    
    
    <h2>Digital</h2>
    <hr class="divline">
    <div class="container">
  <div class='row'>
    <div class='col-md-12'>
        <div class="carousel slide media-carousel" id="media1">  <a href="imageTag.php?tag=digital"><button class="see-more-gallery">See More +</button></a>
        <div class="carousel-inner">
            
                 
            <div class="item active" id="digitalImages">
         <div class="row"> 
                
                
              

                 <?php $counter = 0; ?>
                 <?php  foreach($digitals as $digital): ?>
                 <?php $counter++; //increase counter number
                       if($counter > 4) {break; } 
                 ?>  
 
     <div class="col-md-3">
                  <a class="thumbnail">
<a href="profile.php?userID=<?php echo $image['userID']?>"><?= ($image['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:40px' src='images/{$image['image']}'/>" : "") ?></a>       
                         </a>                         
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
            
            
          <div class="item">
            <div class="row">

                 
                 <?php $counter1 = 0; ?><?php
                 foreach($digitals1 as $digital): ?>
                                 <?php $counter1++; //increase counter number
                       if($counter1 > 4) {break; } 
                 ?>  
<div class="col-md-3">
                  <a href="profile.php?userID=<?php echo $image['userID']?>"><?= ($image['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:40px' src='images/{$image['image']}'/>" : "") ?></a>                        
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
               <div class="item">
            <div class="row">
              
                    <?php $counter2 = 0; ?>
                 <?php  foreach($digitals2 as $digital): ?>
                 <?php $counter2++; //increase counter number
                       if($counter2 > 4) {break; } 
                 ?>  
    <div class="col-md-3">
                  <a class="thumbnail">
<?= ($digital['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:10px; margin-bottom:10px' src='images/{$digital['image']}'/>" : "") ?>          
                         </a>                         
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
            
        </div>
             
        <a data-slide="prev" href="#media1" class="left carousel-control">‹</a>
        <a data-slide="next" href="#media1" class="right carousel-control">›</a>
      </div>                          
    </div>
  </div>
</div>
     
     
    <h2>Painting</h2>
    <hr class="divline">
     <div class="container">
  <div class='row'>
    <div class='col-md-12'>
      <div class="carousel slide media-carousel" id="media2"><a href="imageTag.php?tag=paint"><button class="see-more-gallery">See More +</button></a>
        <div class="carousel-inner">
            
            
     <div class="item active" id="paintImages">
            <div class="row">
              
                    <?php $counter3 = 0; ?>
                 <?php  foreach($paintings1 as $paint): ?>
                 <?php $counter3++; //increase counter number
                       if($counter3 > 4) {break; } 
                 ?>
                <div class="col-md-3">
                  <a class="thumbnail">
<?= ($paint['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:10px; margin-bottom:10px' src='images/{$paint['image']}'/>" : "") ?>        
                         </a>                         
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
            
            
          <div class="item">
            <div class="row">
              
                 <?php $counter4 = 0; ?>
                 <?php  foreach($paintings2 as $paint): ?>
                 <?php $counter4++; //increase counter number
                       if($counter4 > 4) {break; } 
                 ?><div class="col-md-3">
                  <a class="thumbnail">
<?= ($paint['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:10px; margin-bottom:10px' src='images/{$paint['image']}'/>" : "") ?>          
                         </a>                         
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
               <div class="item">
            <div class="row">
              
                <?php $counter5 = 0; ?>
                 <?php  foreach($paintings3 as $paint): ?>
                 <?php $counter5++; //increase counter number
                       if($counter5 > 4) {break; } 
                 ?><div class="col-md-3">
                  <a class="thumbnail">
<?= ($paint['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:10px; margin-bottom:10px' src='images/{$paint['image']}'/>" : "") ?>          
                         </a>                         
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
            
        </div>
        <a data-slide="prev" href="#media2" class="left carousel-control">‹</a>
        <a data-slide="next" href="#media2" class="right carousel-control">›</a>
      </div>                          
    </div>
  </div>
</div>
    
    
    
    
    <h2>Sketches</h2>
    <hr class="divline">
     <div class="container">
  <div class='row'>
    <div class='col-md-12'>
      <div class="carousel slide media-carousel" id="media3"><a href="imageTag.php?tag=pencil"><button class="see-more-gallery">See More +</button></a>
        <div class="carousel-inner">
            
            
     <div class="item active" id="pencilImages">
            <div class="row">
              
                   <?php $counter6 = 0; ?>
                 <?php  foreach($sketches as $sketch): ?>
                 <?php $counter6++; //increase counter number
                       if($counter6 > 4) {break; } 
                 ?>
                <div class="col-md-3">
                  <a class="thumbnail">
<?= ($sketch['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:10px; margin-bottom:10px' src='images/{$sketch['image']}'/>" : "") ?>        
                         </a>                         
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
            
            
          <div class="item">
            <div class="row">
              
                    <?php $counter7 = 0; ?>
                 <?php  foreach($sketches1 as $sketch): ?>
                 <?php $counter7++; //increase counter number
                       if($counter7 > 4) {break; } 
                 ?><div class="col-md-3">
                  <a class="thumbnail">
<?= ($sketch['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:10px; margin-bottom:10px' src='images/{$sketch['image']}'/>" : "") ?>          
                         </a>                         
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
               <div class="item">
            <div class="row">
              
                    <?php $counter8 = 0; ?>
                 <?php  foreach($sketches2 as $sketch): ?>
                 <?php $counter8++; //increase counter number
                       if($counter8 > 4) {break; } 
                 ?><div class="col-md-3">
                  <a class="thumbnail">
<?= ($sketch['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:10px; margin-bottom:10px' src='images/{$sketch['image']}'/>" : "") ?>          
                         </a>                         
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
            
        </div>
        
        <a data-slide="prev" href="#media3" class="left carousel-control">‹</a>
        <a data-slide="next" href="#media3" class="right carousel-control">›</a>
      </div>                          
    </div>
  </div>
</div>
    
    <h2>Colouring</h2>
    <hr class="divline">
     <div class="container">
  <div class='row'>
    <div class='col-md-12'>
      <div class="carousel slide media-carousel" id="media4"><a href="imageTag.php?tag=colour"><button class="see-more-gallery">See More +</button></a>
        <div class="carousel-inner">
            
            
     <div class="item active" id="colourImages">
            <div class="row">
              
                 <?php $counter9 = 0; ?>
                 <?php  foreach($colourings as $colour): ?>
                 <?php $counter9++; //increase counter number
                       if($counter9 > 4) {break; } 
                 ?><div class="col-md-3">
                  <a class="thumbnail">
<?= ($colour['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:10px; margin-bottom:10px' src='images/{$colour['image']}'/>" : "") ?>        
                         </a>                         
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
            
            
          <div class="item">
            <div class="row">
              
                   <?php $counter10 = 0; ?>
                 <?php  foreach($colourings1 as $colour): ?>
                 <?php $counter10++; //increase counter number
                       if($counter10 > 4) {break; } 
                 ?><div class="col-md-3">
                  <a class="thumbnail">
<?= ($colour['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:10px; margin-bottom:10px' src='images/{$colour['image']}'/>" : "") ?>          
                         </a>                         
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
               <div class="item">
            <div class="row">
              
                    <?php $counter11 = 0; ?>
                 <?php  foreach($colourings2 as $colour): ?>
                 <?php $counter11++; //increase counter number
                       if($counter11 > 4) {break; } 
                 ?><div class="col-md-3">
                  <a class="thumbnail">
<?= ($colour['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:10px; margin-bottom:10px' src='images/{$colour['image']}'/>" : "") ?>          
                         </a>                         
 </div>   
  <?php endforeach; ?> 
                  
           
            </div>
          </div>
            
        </div>
        <a data-slide="prev" href="#media4" class="left carousel-control">‹</a>
        <a data-slide="next" href="#media4" class="right carousel-control">›</a>
      </div>                          
    </div>
  </div>
</div>

       
     <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
                        
     <?php include_once 'includes/footer.php'; ?>
  </body>
</html>