<!DOCTYPE html>
<html>
    <head>
          <title>F.A.Q</title>
          <?php include_once 'includes/headlinks.php'; ?>
          <?php include_once 'includes/font.php'; ?>
    </head>
    <body>
        <div class="backset">
       <?php                session_start();
          require_once('includes/database.php');
         require_once('includes/header.php');
 ?>
        <main>
        <div class="container">
            <h2 class="form-title">F.A.Q</h2><hr class="divline"><br>
            <div class="faq-body">
               
            <h4>-What is ArtSource?</h4>
<p>ArtSource is simply a hosting site that allows people seeking custom artwork to get in contact with the perfect artist for them. 
The only paywalls are those established between you and your artist, so you can browse our entire library for free. 
No fees, no frills, no fuss.</p>

<h4>-How does it work?</h4>
<p>When you find an image you like, you can click on it to view an artist's profile to see their other work and get a feel for their style. 
If it's what you're looking for, perfect! Get in touch with the artist by sending them a message via our built-in contact form, 
and they'll get back to you as soon as they can. Once you've made initial contact, the artist will e-mail you details about the project, 
the exact cost, and progress updates, etc.</p>

<h4>-Why don't you facilitate payment?</h4>
<p>We are not an online store. We are simply a facility through which artists and potential clients can connect. 
    The exact details of a commission are between a client and an artist.</p>

<h4>-Well how do I pay then?</h4>
<p>While you can use online banking if your bank provides it, we highly recommend using PayPal. 
That way, if either the artist or client is unhappy, it's very easy to find a solution. 
In the case of PayPal disputes, get in contact with an administrator for the initial contact form send by the client to help in your 
appeal case.</p>

<h4>-How does your site keep running without payments?</h4>
<p>Through generous donations from users like you. Servers are expensive, but we have a strict anti-"pay-to-win" policy, 
meaning we will never offer paid promotions to users, assuring that all our featured artists are truly deserving of it. 
You can donate to us here to keep ArtSource free and fair.</p>

<a href="signUp.php"><button class="sign-up-faq">Got it?

        Okay, let's get you started.</button></a>
            </div>
        </div>
        </main>

        </div>        
        <?php include_once 'includes/footer.php'; ?>        
          
    </body>
</html>

