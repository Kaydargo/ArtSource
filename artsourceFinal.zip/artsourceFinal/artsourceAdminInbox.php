<!DOCTYPE html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css"  />
<?php include_once'includes/headlinks.php'?>
</head>



<body>

<?php                session_start();
          require_once('includes/database.php');
          require_once('includes/header.php');
 ?>
    
<a href="artsourceAdminNav.php"><button class="admin-back-page-button-in">Back</button></a>

    <div class="admin-edit-content">
 <h3 class="table-title-in" >Showing All Users</h3>
 <h5 class="table-title-in">Click headers to sort</h5>
 <table class="user-table" id="messageTable" align="center">
 <tr> 
 <th scope="col"onclick="sortTable(0)">Name</th>
 <th scope="col"onclick="sortTable(1)">Email</th>
 <th scope="col" onclick="sortTable(2)">Topic</th>
 <th scope="col">Message</th>
 <th scopt="col"onclick="sortTable(3)">Received</th>
 </tr>
 <tr>     
     <td >TwnPks</td>
     <td >laura@palmer.com</td>
     <td >Report</td>
     <td>Artist Orlaith was posting art stolen from my friend. Please investigate.</td>
     <td>2018-04-24 23:26</td>
     
 </tr>
 <tr>     
     <td>BnHA</td>
     <td>aura@palmer.com</td>
     <td>Misc</td>
     <td>Artist Orlaith was posting art stolen from my friend. Please investigate. 
     This is some more text. How are you today :).</td>
     <td>2018-04-23 23:26</td>
     
 </tr>
 <tr>
     
     <td>Steven</td>
     <td>ra@palmer.com</td>
     <td>Report</td>
     <td>Artist Orlaith was posting art stolen from my friend. Please investigate.</td>
     <td>2018-04-24 20:26</td>
     
 </tr>
 </table>
 <!--THIS IS WHERE THE PHP TABLE WILL GO, THE TABLE AND VALUES CURRENTLY IN THE HTML ARE FOR STYLING PURPOSES ONLY-->
<?php
// foreach($obj->showData("users") as $value){
// extract($value);
// echo <<<show
// <tr>
// <td>$name</td>
// <td>$email</td>
// <td>$topic</td>
// <td>$message</td>
// <td>$date</td>
// 
//

// ?>
<!-- <tr class="success">
 <th scope="col" colspan="5" align="right">
 <div class="btn-group">
 <button class="btn"><a href="insert.php">Insert New Data</a></button>
 </div>
 </th>

 </tr>-->
 </table>

    </div>
</div>

</body>
<script>
    function sortTable(n) {
  var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
  table = document.getElementById("messageTable");
  switching = true;
  //Set the sorting direction to ascending:
  dir = "asc"; 
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.getElementsByTagName("TR");
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[n];
      y = rows[i + 1].getElementsByTagName("TD")[n];
      /*check if the two rows should switch place,
      based on the direction, asc or desc:*/
      if (dir == "asc") {
        if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch= true;
          break;
        }
      } else if (dir == "desc") {
        if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch= true;
          break;
        }
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
      //Each time a switch is done, increase this count by 1:
      switchcount ++;      
    } else {
      /*If no switching has been done AND the direction is "asc",
      set the direction to "desc" and run the while loop again.*/
      if (switchcount == 0 && dir == "asc") {
        dir = "desc";
        switching = true;
      }
    }
  }
}
</script>
</html>












