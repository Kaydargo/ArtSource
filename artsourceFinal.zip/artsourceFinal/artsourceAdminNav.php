<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        
        <title>Admin Nav</title>
       <?php include_once'includes/headlinks.php';
                    session_start();
          require_once('includes/database.php');
          $queryUser = "SELECT * FROM users";
            $statement2 = $db->prepare($queryUser);
            $statement2->execute();
            $headers = $statement2->fetchAll();
            $statement2->closeCursor();
            
            $type= 'type';
if($type == "admin") {
    include'includes/headerADMIN.php';
} 

else if ($type == "User" || $type == "Artist"){
    include'includes/headerLI.php';
}

else
{
    include'includes/headerLG.php';
}
?>
    </head>
    <body>
<?php include_once 'includes/header.php';?>        
        <div class="backset">
        <main>
            <h2 class="form-title">Welcome Administrator</h2>
            <h4 class="form-title">What would you like to do today?</h4>
            <div id="adminnav1">            
            <a href="artsourceAdminUsers.php"><button class="admin-nav-button" id="editusers">Edit Users</button></a>
            <a href="artsourceAdminInbox.php"><button class="admin-nav-button" id="viewmessages">View Messages</button></a>
            </div>            
        </main>
    </div> 
<?php include_once'includes/footer.php';?>        
    </body>
    
</html>
