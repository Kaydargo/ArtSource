<!DOCTYPE html>
<html>
<head>
<title>Your Home Page</title>
<?php include_once('includes/headlinks.php'); ?>
<script src="jQuery/password.js" type="text/javascript"></script>
</head>
<body>
    <script type="text/javascript">
            function confirmPass() {
                var pass = document.getElementById("pass").value
                var confPass = document.getElementById("c_pass").value
                if (pass != confPass) {
                    alert("Password Doesn't Match! Please confirm your password.");
                }
            }
        </script>
     <?php                session_start();
          require_once('includes/database.php');
         require_once('includes/header.php');

    ?>
             <?php 
require_once('includes/database.php');
$userID= $_SESSION['userID'];
    $queryUser = "SELECT * FROM users WHERE userID = $userID"; 
    $statement2 = $db->prepare($queryUser);
    $statement2->execute();
    $users = $statement2->fetchAll();
    $statement2->closeCursor();
    
    ?>
    
                 <?php 
require_once('includes/database.php');

//Selects all images, their id and userid with the tag animated

    $queryImages = "SELECT * FROM image WHERE userID = $userID LIMIT 6"; 
    $statement3 = $db->prepare($queryImages);
    $statement3->execute();
    $images = $statement3->fetchAll();
    $statement3->closeCursor();
    ?>


    <h2 class="form-title">Editing : <i><?php  echo $username = $_SESSION['username']; ?></i></h2><hr class="divline">
        <?php foreach ($users as $user) : ?>
    
    <div class="container">
      <div class="row">
      <div class="col-md-2  toppad  pull-right col-md-offset-3 sideber-high">
          <p><a href="homeProfile.php" target="_blank" ><button class="home-profile-buttons">View Profile</button></a></p><br> 
          <a href="addImageForm.php"><button class="home-profile-buttons">Add Image</button></a>
       <br>

      </div>
        <div class="col-md-12 col-md-12 col-md-10 col-lg-10 col-md-offset-2 col-sm-offset-5 col-md-offset-15 col-lg-offset-15 toppad" >
   
   
          <div class="panel panel-info">
              <form id="editArtistProfile" method="POST" action="editProfile.php">
            <div class="panel-heading">
                
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-lg-3 col-lg-3 " align="center"> <img alt="User Pic" src="images/<?php echo $user['profilePic']; ?>" class="img-square img-responsive"> </div>
                
                <div class=" col-md-2 col-lg-2 "> 
                  <table class="table table-user-information">
                    <body>
                    <tr>
                        <td>New Username:</td>
                        <td><input id="newUsername" value="<?php echo $user['username']; ?>"></td>
                    </tr>
                    
                     <label for="pass">Password</label><br>
                    <input type="password" id="pass" class="text" name="password" value="<?php echo $user['username']; ?>" />
                    <br><br>
                    
                    <label for="c_pass">Confirm Password</label><br>
                    <input type="password" id="c_pass" class="text" onblur="confirmPass()"/>
                      <tr>
                        <td>Average Price:</td>
                        <td><input id="newPrice" value="<?php echo $user['avgPrice']; ?>"></td>
                      </tr>
                      <tr>
                        <td>Location:</td>
                        <td><input id="newLocation" value="<?php echo $user['location']; ?>"></td>
                      </tr>
                      
                      <tr>
                        <td>Speciality</td>
                        <td><input id="newSpeciality" value="<?php echo $user['speciality']; ?>"></td>
                      </tr>
                   

                             <tr>
                        <td>Contact</td>
                        <td><input id="newContact" value="<?php echo $user['email']; ?>"></td>
                      </tr>

                         
                         <tr>
                        <td>About Me:</td>
                        <td><input type="textarea" name="bio" value="<?php echo $user['bio']; ?>"></td>
                      </tr>
                      
                      
                          <tr><td>First Name:</td>
                          <td><input id="newFirstname" value="<?php echo $user['firstname']; ?> "></td></tr>
                          
                          <tr><td>Surname:</td>
                          <td><input id="newSurname" value="<?php echo $user['lastname'];?>"></td></tr>                     
                      
                      <tr><td>Change Profile Picture:</td>
                          <td><input type="file" value=""></td>
                      </tr>
                  </table>
                  
                </div>
              </div>
            </div>
                  <input type="submit" value="Go!" name="submit" class="edit-submit">
              </form>
          </div>
        </div>
      </div>
    </div>  
    
    <?php endforeach; ?>    
    
    
    

    <footer><?php include_once 'includes/footer.php'; ?></footer>
</body>
</html><!DOCTYPE html>
<html>
<head>
<title>Editing Profile</title>
<?php include_once'includes/headlinks.php';?>
      <?php include_once'includes/font.php';?>
</head>
<body>
    
     <?php include_once 'includes/header.php';
     session_start();
    ?>
             <?php 
require_once('includes/database.php');
$userID= $_SESSION['userID'];
    $queryUser = "SELECT userID, firstname, lastname, username, avgPrice, location, email , speciality, bio FROM users WHERE userID = $userID"; 
    $statement2 = $db->prepare($queryUser);
    $statement2->execute();
    $users = $statement2->fetchAll();
    $statement2->closeCursor();
    
    ?>
    
                 <?php 
require_once('includes/database.php');

//Selects all images, their id and userid with the tag animated

    $queryImages = "SELECT * FROM image WHERE userID = $userID LIMIT 6"; 
    $statement3 = $db->prepare($queryImages);
    $statement3->execute();
    $images = $statement3->fetchAll();
    $statement3->closeCursor();
    ?>


    <h2 class="form-title">Editing : <i><?php  echo $username = $_SESSION['username']; ?></i></h2><hr class="divline">
        <?php foreach ($users as $user) : ?>
    
    <div class="container">
      <div class="row">
      <div class="col-md-2  toppad  pull-right col-md-offset-3 sideber-high">
          <p><a href="homeProfile.php" target="_blank" ><button class="home-profile-buttons">View Profile</button></a></p><br>
          <p><a><button class="home-profile-buttons">Change image</button></a></p><br> 
          <a href="addImageForm.php"><button class="home-profile-buttons">Add Image</button></a>
       <br>

      </div>
        <div class="col-md-12 col-md-12 col-md-10 col-lg-10 col-md-offset-2 col-sm-offset-5 col-md-offset-15 col-lg-offset-15 toppad" >
   
   
          <div class="panel panel-info">
              <form id="editArtistProfile" action="editProfile.php">
            <div class="panel-heading">
                
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-lg-3 col-lg-3 " align="center"> <img alt="User Pic" src="http://www.profightdb.com/img/wrestlers/thumbs-600/4d54a6c767johncena.jpg" class="img-square img-responsive"> </div>
                
                <div class=" col-md-2 col-lg-2 "> 
                  <table class="table table-user-information">
                    <body>
                    <tr>
                        <td>Firstname:</td>
                        <td><input id="newFirstname" value="<?php echo $user['firstname']?>"</td>
                    </tr>
                    <tr>
                        <td>Surname:</td>
                        <td><input id="newSurname" value="<?php echo $user['lastname']?>"</td>
                    </tr>
                    <tr>
                        <td>Username:</td>
                        <td><input id="newUsername" value="<?php echo $user['username']; ?>"></td>
                    </tr>
                      <tr>
                        <td>Average Price:</td>
                        <td><input id="newPrice" value="<?php echo $user['avgPrice']; ?>"></td>
                      </tr>
                      <tr>
                        <td>Location:</td>
                        <td><input id="newLocation" value="<?php echo $user['location']; ?>"></td>
                      </tr>
                      
                      <tr>
                        <td>Speciality</td>
                        <td><input id="newSpeciality" value="<?php echo $user['speciality']; ?>"></td>
                      </tr>
                   

                             <tr>
                        <td>Contact</td>
                        <td><input id="newContact" value="<?php echo $user['email']; ?>"></td>
                      </tr>

                         
                         <tr>
                        <td>About Me:</td>
                        <td><textarea name="bio" value="<?php echo $user['bio']; ?>"></textarea></td>
                      </tr>
                      
                      
                          <tr><td>First Name:</td>
                          <td><input id="newFirstname" value="<?php echo $user['firstname']; ?> "></td></tr>
                          
                          <tr><td>Surname:</td>
                          <td><input id="newSurname" value="<?php echo $user['lastname'];?>"></td></tr>
                                                   
                          
                          <tr><td>Password:</td>
                          <td><input type="password" id="newPassword"><?php echo $user['password']?></td></tr>
                          
                          <tr><td>Confirm Password:</td>
                          <td><input type="password" id="confirmNewPassword"></td></tr>
                          <div class="registrationFormAlert" id="checkPasswordMatch"></div>
                          <script>
                              function checkPasswordMatch(){
                                  var password = $("#newPassword").val();
                                  var confirmPassword = $("#confirmNewPassword").val();
                                  
                                  if(password !== confirmPassword)
                                      $("#checkPasswordMatch").html("Passwords do not match");
                                 else
                                     $("#checkPasswordMatch").html("Passwords Match");
                              }
                              $(document).ready(funtion(){
                                  $("#confirmNewPassword").keyup(checkPasswordMatch);
                              });
                          </script>
                      </tr>
                  </table>
                  
                </div>
              </div>
            </div>
                  <input type="submit" value="Go!" name="submit" class="edit-submit">
              </form>
          </div>
        </div>
      </div>
    </div>  
    
    <?php endforeach; ?>    
    
    
    

    <footer><?php include_once 'includes/footer.php'; ?></footer>
</body>
</html>