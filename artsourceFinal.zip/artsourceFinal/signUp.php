<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Sign Up</title>
        <?php include_once'includes/headlinks.php';?>
                <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="jQuery/password.js" type="text/javascript"></script>
    </head>
    <body>
    <script>
$(document).ready(function(){
    $("#hide").click(function(){
        $(".price").hide();
    });
    $("#show").click(function(){
        $(".price").show();
    });
});
</script>

<script type="text/javascript">
            function confirmPass() {
                var pass = document.getElementById("pass").value
                var confPass = document.getElementById("c_pass").value
                if (pass != confPass) {
                    alert("Password Doesn't Match! Please confirm your password.");
                }
            }
        </script>
             <?php                session_start();
          require_once('includes/database.php');
       require_once('includes/header.php');
 ?>
  
        <h1 class="form-title">Sign Up</h1><hr class="divline"><br>
        <div class="signup-container">
        <form method="POST" action="insertUser.php">
            <label class="form-label">First Name: &nbsp;</label><br>
            <input type="text" name="firstname" id="firstname" class="form-input-single" placeholder="First Name"><span class="required">*</span><br><br>
            
            <label class="form-label">Surname: &nbsp;</label><br>
            <input type="text" name="lastname" id="lastname" class="form-input-single" placeholder="Surname"><span class="required">*</span><br><br>
            
            <label class="form-label">Username: &nbsp;</label><br>
            <input type="text" name="username" id="username" class="form-input-single" placeholder="Username"><span class="required">*</span><br><br>
            
            <label class="form-label">E-mail: &nbsp;</label><br>
            <input type="email" name="email" id="email" class="form-input-single" placeholder="E-mail"><span class="required">*</span><br><br>
            
                    <label for="pass">Password</label><br>
                    <input type="password" id="pass" class="text" pattern=".{6}" required /><span class="required">*</span>
                    <br><br>
                    <label for="c_pass">Confirm Password</label><br>
                    <input type="password" id="c_pass" class="text" name="password" onblur="confirmPass()"/><br><br>

            
            <label class="form-label-shift-left">Address: &nbsp;</label><br>
            <input type="textbox" name="location" id="location" class="form-input-textbox" placeholder="Use as much or little information as you like."><br><br><br><br>
            
            <label class="form-label">Are you signing up as an artist or a customer? (you can always change this later)</label><br><br>
            
          <input type="radio" id="show" name="type" value="Artist" checked>Artist<br>
            <input type="radio" id="hide" name="type" value="Customer">Customer<br><br>
            

            <label class="form-label price">What is the average price of your commissions?</label><br>
            <input type="text" name="avgPrice" id="avgcost" class="form-input-single price"><br><br>

                
                       
            <label>Date of Birth:</label><br>
            <input type="input" name="dob" id="datepicker" placeholder='Add date of birth' id="datepicker" class="form-input-datepicker form-input-single">
            <script>        
$( function() {
               var date = $('#datepicker').datepicker({ dateFormat: 'yy-mm-dd'}).val();
              $( "#datepicker" ).datepicker();
              
            } );
                    </script><br><br>
            <input type="submit" class="signup-submit" value="Go!">
            <br><br><br>
            <div>
                <p>
                    Already have an account? <a href="login.php">Login</a> <br> 
                </p>
            </div>
            </div>
        </form>  
    
           <?php include_once 'includes/footer.php'; ?>
    </body>
</html>