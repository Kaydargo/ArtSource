<html>
    <head>
          <title>Contact</title>
<?php include_once('includes/headlinks.php'); ?>
    </head>
<div class="signup-container">
    <body>
        
        <br>
        
   <?php 
               session_start();
          require_once('includes/database.php');
          require_once('includes/header.php');

    $queryUsers = "SELECT userID, email FROM users";
    $statement3 = $db->prepare($queryUsers);
    $statement3->execute();
    $users = $statement3->fetchAll();
    $statement3->closeCursor();

    ?>
        <br>
    
    <div class="container">
        <h2 style="margin-left: -85%">Contact Us</h2>

    <script>
      function countChar(val) {
        var len = val.value.length;
        if (len >= 500) {
          val.value = val.value.substring(0, 500);
        } else {
          $('#charNum').text(500 - len);
        }
      };
    </script>
  </head>
  
<div class="form-row">
    <form class="form-horizontal" method="POST" action="contact_query.php">
       
            <br>
        <div class="form-group col-md-6">
    	<p class="firstname">
            <label for="firstname">Your First Name</label>
    		<input type="text" name="firstname" id="firstname" placeholder="First name" autofocus="autofocus" required/>	
    	</p>
        </div>
            
     <input type="hidden" name="recipientID" value="<?php echo $userID ?> " class="form-control" >
     
        <div class="form-group col-md-6">
    	<p class="email">
            <label for="email">Email Address</label>

    		<input type="email" name="email" id="email" placeholder="Email Address" required/>
    	</p>	
        </div>
         <div class="form-group col-md-6">
        <p class="subject">
           <label for="subject">Your Subject</label>
          <select name="subject">
	  <option value="">Select...</option>
	  <option value="account">Account</option>
	  <option value="pay">Payment</option>
          <option value="user">User dispute</option>
          <option value="report">Report user</option>
          </select>
    	</p>
        <p>
            
	<label>Image to upload: </label><br>
              <input type="file" name="image" value="image" id="image"><br><br>
	</p>
         </div>
        
        <div class="form-group col-md-6">
    	<p class="message">
            <label for="message">Your Message</label>
    		<textarea name="message" placeholder="" required onkeyup="countChar(this)"></textarea>
               <div id="charNum"></div>
    	</p>
        
        </div>

        <div class="control-group">
                <div class="controls">
                        <button type="submit" name="send_message" class="submit-admin-msg"><i class="icon-ok icon-large"></i> Submit</button>
                </div>
        </div>
            </div>
  </div>
  </div>
        <br><br><br>
     
    </form>
 
       
    </body> 
        <?php include_once 'includes/footer.php'; ?>
</html>
 
</div>
                </div>
        </div>
            </div>
  </div>
    <br><br>
    
        <?php include_once 'includes/footer.php'; ?>
    </body>
</html>
