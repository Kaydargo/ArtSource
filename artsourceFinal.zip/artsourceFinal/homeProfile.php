<!DOCTYPE html>
<html>
<head>
<title>Your Home Page</title>
<?php include_once 'includes/headlinks.php';?>
</head>
<body>

    <?php
    
    require_once('includes/database.php');
           require_once('includes/header.php');
?>
    
             <?php 
         session_start();
    $userID= $_SESSION['userID'];


    $queryUser = "SELECT userID, username, avgPrice, location, email , type, speciality, bio, profilePic FROM users WHERE userID = $userID"; 
    $statement2 = $db->prepare($queryUser);
    $statement2->execute();
    $users = $statement2->fetchAll();
    $statement2->closeCursor();
    
    ?>
    
                 <?php 
require_once('includes/database.php');

//Selects all images, their id and userid with the tag animated

    $queryImages = "SELECT * FROM image WHERE userID = $userID LIMIT 6"; 
    $statement3 = $db->prepare($queryImages);
    $statement3->execute();
    $images = $statement3->fetchAll();
    $statement3->closeCursor();
    ?>

<div id="profile">
        <?php foreach ($users as $user) : ?>
        <tr>
                        

        </tr><br><br>
        
        <br>

</div>


<div class="container">
      <div class="row">
      <div class="col-md-2  toppad  pull-right col-md-offset-3 profile-sidebar">
          <p id="logout" >
              <a href="logout.php"><button class="home-profile-buttons">Log Out</button></a></p><br><br>
          <a href="editProfileForm.php?userID=<?php echo $user['userID']; ?>"><button class="home-profile-buttons">Edit Profile</button></a></p><br><br>
      <a href="userMessages.php?userID=<?php echo $user['userID']; ?>"><button class="home-profile-buttons">Inbox</button></a></p>
<br>
<?php
    if($user['type'] === "Admin"){
echo '<a href="artsourceAdminNav.php"><button class="home-profile-button">Admin</button></a>';
}
else {
    
}
?>
<br>

      </div>
        <div class="col-md-12 col-md-12 col-md-10 col-lg-10 col-md-offset-2 col-sm-offset-5 col-md-offset-15 col-lg-offset-15 toppad" >
          <div class="panel panel-info">
            <div class="panel-heading">
              <h1 class="panel-title"><?php echo $user['username']; ?></h1>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td>Average:</td>
                        <td>€<?php echo $user['avgPrice']; ?></td>
                      </tr>
                      <tr>
                        <td>Location:</td>
                        <td><?php echo $user['location']; ?></td>
                      </tr>
                      <tr>
                        <td>Speciality</td>
                        <td><?php echo $user['speciality']; ?></td>
                      </tr>
                   
                         <tr>
                             <tr>
                        <td>Contact</td>
                        <td><?php echo $user['email']; ?></td>
                      </tr>
                         </tr>
                         <tr>
                        <td>About Me:</td>
                        <td><?php echo $user['bio']; ?></td>
                      </tr>
                     
                    </tbody>
                  </table>
                  
                </div>
                <div class="col-lg-3 col-lg-3 " align="right"> <img alt="User Pic" src="images/<?php echo $user['profilePic']; ?>" class="img-square img-responsive"> </div>
              </div>
                 
            </div>

          </div>
        </div>
      </div>
    </div>   
    
    
    
   <h2>Other Work</h2>
    <hr class="divline">
    <a href="userImages.php?userID=<?php echo $user['userID']?>"><button class="see-more-portfolio">See More +</button></a>
    <?php endforeach; ?>
      <div class="panel panel-default"><br><br>   
                  <div class="panel-body">
                    <div class="row">
 <?php
 foreach($images as $image): 
     ?>
                        </br> 
                        <div class="col-md-2">  
                         <?= ($image['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:40px' src='images/{$image['image']}'/>" : "") ?>          
                                                  
                       </div> 
  <?php endforeach; ?>      
            <!-- End of Foreach Statement -->
            
        </div>
       </div>
     </div>
    

     <?php include_once 'includes/footer.php'; ?>
</body>
</html>