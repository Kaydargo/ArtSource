<?php
// Get the product data
$firstname = filter_input(INPUT_POST, 'firstname');
$lastname = filter_input(INPUT_POST, 'lastname');
$username = filter_input(INPUT_POST, 'username');
$email = filter_input(INPUT_POST, 'email');
$profilePic = filter_input(INPUT_POST, 'profilePic');
$password = filter_input(INPUT_POST, 'password');
$location = filter_input(INPUT_POST, 'location');
$speciality =  filter_input(INPUT_POST, 'speciality');
$bio =  filter_input(INPUT_POST, 'bio');
$avgPrice =  filter_input(INPUT_POST, 'avgPrice', FILTER_VALIDATE_FLOAT);

// Validate inputs
if ($firstname == null || $lastname == null || $email == null|| $password == null || $location == null) {
    $error = "Invalid user data. Check all fields and try again.";
    include('error.php');
} else {
    require_once('includes/database.php');

    // Add the product to the database 
   $query = 'UPDATE users SET 
                  firstname = :firstname,
                  lastname = :lastname,
                  email = :email,
                  profilePic =:profilePic,                  
                  password = :password,
                  location= :location,
                  avgPrice= :avgPrice,
                  bio =:bio,
                  speciality= :speciality,
               WHERE userID = :userID';
    $statement = $db->prepare($query);
    $statement->bindValue(':firstname', $firstname);
    $statement->bindValue(':lastname', $lastname);
    $statement->bindValue(':username', $username);
    $statement->bindValue(':email', $email);
    $statement->bindValue(':profilePic', $profilePic);
    $statement->bindValue(':password', $password);
    $statement->bindValue(':location', $location);    
    $statement->bindValue(':bio', $bio);
    $statement->bindValue(':speciality', $speciality);
    $statement->bindValue(':avgPrice', $avgPrice);
    $statement->execute();
    $statement->closeCursor();

    // Display the Product List page
    include('homeProfile.php');
}
?>