<!DOCTYPE html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css"  />
<?php include_once'includes/headlinks.php'?>
<title>Your Inbox</title>
</head>



<body>
<?php 
               session_start();
          require_once('includes/database.php');
          require_once('includes/header.php');

          $userID = filter_input(INPUT_GET, "userID");
          
    $queryUser = "SELECT * FROM message WHERE RecipientID = $userID"; 
    $statement2 = $db->prepare($queryUser);
    $statement2->execute();
    $users = $statement2->fetchAll();
    $statement2->closeCursor();

?>
    
 <h3 >Showing All Messages</h3>

        <?php foreach ($users as $user) : ?>
    
    <div class="admin-edit-content">

 <table class="user-table" id="messageTable" align="center">
 <tr> 
     <th scope="col"onclick="sortTable(0)">Name</th>
 <th scope="col"onclick="sortTable(1)">Email</th> 
 <th scope="col">Message</th>
 <th scopt="col"onclick="sortTable(2)">Received</th>
 </tr>
 <tr>     
     <td ><?php echo $user['firstname']; ?></td>
     <td ><?php echo $user['email']; ?></td>     
     <td><?php echo $user['message']; ?></td>
     <td><?php echo $user['messageTime']; ?></td>
     
 </tr>
 </table>

    </div>

   <?php endforeach; ?>
 <br><br>
 <?php include_once 'includes/footer.php'; ?>
</body>
<script>
    function sortTable(n) {
  var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
  table = document.getElementById("messageTable");
  switching = true;
  //Set the sorting direction to ascending:
  dir = "asc"; 
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.getElementsByTagName("TR");
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[n];
      y = rows[i + 1].getElementsByTagName("TD")[n];
      /*check if the two rows should switch place,
      based on the direction, asc or desc:*/
      if (dir == "asc") {
        if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch= true;
          break;
        }
      } else if (dir == "desc") {
        if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch= true;
          break;
        }
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
      //Each time a switch is done, increase this count by 1:
      switchcount ++;      
    } else {
      /*If no switching has been done AND the direction is "asc",
      set the direction to "desc" and run the while loop again.*/
      if (switchcount == 0 && dir == "asc") {
        dir = "desc";
        switching = true;
      }
    }
  }
}
</script>
</html>












