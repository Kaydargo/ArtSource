<!DOCTYPE html>
<html>
<head>
<title>Your Home Page</title>
<?php include_once'includes/headlinks.php';?>
<?php include_once'includes/font.php';?>
</head>
<body>
  <?php include 'header.php'; ?>  
    ?>
    <?php
   //Start your session
   session_start();
//   Read your session (if it is set)
//   if (isset($_SESSION)) {
//       print_r("<pre>");
//       print_r($_SESSION);
//       print_r("</pre>");
//}
?>
    
             <?php 
require_once('includes/database.php');
    $userID= $_SESSION['userID'];


    $queryUser = "SELECT userID, username, avgPrice, location, email , speciality, bio FROM users WHERE userID = $userID"; 
    $statement2 = $db->prepare($queryUser);
    $statement2->execute();
    $users = $statement2->fetchAll();
    $statement2->closeCursor();
    
    ?>
    
                 <?php 
require_once('includes/database.php');

//Selects all images, their id and userid with the tag animated

    $queryImages = "SELECT * FROM image WHERE userID = $userID LIMIT 6"; 
    $statement3 = $db->prepare($queryImages);
    $statement3->execute();
    $images = $statement3->fetchAll();
    $statement3->closeCursor();
    ?>

<div id="profile">
        <?php foreach ($users as $user) : ?>
        <tr>
                        

        </tr><br><br>
        
        <br>
<p id="logout"><a href="logout.php">Log Out</a></p>
</div>


<div class="container">
      <div class="row">
      <div class="col-md-2  toppad  pull-right col-md-offset-3 ">
          <a href="editProfileForm.php" >Edit Profile</a>
       <br>

      </div>
        <div class="col-md-12 col-md-12 col-md-10 col-lg-10 col-md-offset-2 col-sm-offset-5 col-md-offset-15 col-lg-offset-15 toppad" >
          <div class="panel panel-info">
            <div class="panel-heading">
              <h1 class="panel-title"><?php echo $user['username']; ?></h1>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                  
                      <tr>
                        <td>Location:</td>
                        <td><?php echo $user['location']; ?></td>
                      </tr>               
                         <tr>
                             <tr>
                        <td>Contact</td>
                        <td><?php echo $user['email']; ?></td>
                      </tr>
                         </tr>
                         <tr>
                        <td>About Me:</td>
                        <td><?php echo $user['bio']; ?></td>
                      </tr>
                     
                    </tbody>
                  </table>
                  
                </div>
                <div class="col-lg-3 col-lg-3 " align="right"> <img alt="User Pic" src="http://www.profightdb.com/img/wrestlers/thumbs-600/4d54a6c767johncena.jpg" class="img-square img-responsive"> </div>
              </div>
                 
            </div>

          </div>
        </div>
      </div>
    </div>   
    <?php endforeach; ?>
    
    
    <h2>Other Work</h2>
      <div class="panel panel-default"><br><br>   
                  <div class="panel-body">
                    <div class="row">
 <?php
 foreach($images as $image): 
     ?>
                        </br> 
                        <div class="col-md-2">  
                         <?= ($image['image'] <> " " ? "<img style='width:200px; height:200px; margin-top:40px' src='images/{$image['image']}'/>" : "") ?>          
                                                  
                       </div> 
  <?php endforeach; ?>      
            <!-- End of Foreach Statement -->
            
        </div>
       </div>
     </div>
    

<?php include 'footer.php'; ?>  
</body>
</html>