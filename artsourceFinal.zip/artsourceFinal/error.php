<html>
    <head>
        <?php include_once('includes/headlinks.php'); 
                       session_start();
          require_once('includes/database.php');
          $queryUser = "SELECT * FROM users";
            $statement2 = $db->prepare($queryUser);
            $statement2->execute();
            $headers = $statement2->fetchAll();
            $statement2->closeCursor();
            
            $type= 'type';
if($type == "Admin") {
    include'includes/headerADMIN.php';
} 

else if ($type == "User" || $type == "Artist"){
    include'includes/headerLI.php';
}

else
{
    include'includes/headerLG.php';
}

?>
        <title>Error!</title>
    </head>
    <body>
 <div class="container">
<!--Page Heading -->
        <h1 class="mt-4 mb-3">Error page</h1>
        <div class="row"><br>

            <!-- Post Content Column -->
            <div class="col-lg-8">

        <h2 class="top">We have a problem</h2>
        <p><?php echo $error; ?></p>
              
            </div>
      
</div><!-- End row -->

 </div>      <br><br><br><br><br><br><br><br> <br> <br><br><br><br><br>     

<?php
include 'includes/footer.php';
?>
    </body>
</html>
         