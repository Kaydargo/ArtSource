<?php
    include ('includes/database.php');
    session_start();
       
// Get the user data
    
      if (isset($_SESSION)) {
            $userID = $_SESSION['userID'];
       }
       else {
           $userID = 0;
       }
       echo $userID;
    
$firstname = filter_input(INPUT_POST, 'firstname');
$email = filter_input(INPUT_POST, 'email');
$recipientID = filter_input(INPUT_POST, 'recipientID');
$message = filter_input(INPUT_POST, 'message');
$subject = filter_input(INPUT_POST, 'subject');

// Validate inputs
if ( $userID == null || $firstname == null || $email == null || $message == null) {
    $error = "Invalid contact data. Check all fields and try again.";
    include('error.php');
} else {
    require_once('includes/database.php');

    // Add the product to the database 
    $query = "INSERT INTO message (userID, firstname, email, recipientID, message, subject)
    VALUES (:userID, :firstname, :email, :recipientID, :message , :subject)";
    $statement = $db->prepare($query);
    $statement->bindValue(':userID', $userID);
    $statement->bindValue(':firstname', $firstname);
    $statement->bindValue(':email', $email);
    $statement->bindValue(':recipientID', $recipientID);
    $statement->bindValue(':message', $message);
    $statement->bindValue(':subject', $subject);
    $statement->execute();
    $statement->closeCursor();

    header("Location:index.php");
die();
}
?>