<!--aka i got bored of copy pasting all this junk every time-->
<!--normal stuff-->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" href="images/icon-art.png">
<!--stylesheets  NOTE, "css/stylesheet.css must ALWAYS be last since its the only one where edits are being made-->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="../css/lightboxStyle.css" rel="stylesheet" type="text/css"/>
<link href="css/thumbnail-gallery.css" rel="stylesheet">
<link href="css/stylesheet.css" rel="stylesheet" type="text/css"/>
<!--scripts and jQuery libraries-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="jQuery/artsource.js" type="text/javascript"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-1.5.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--fonts-->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">

