    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
          <p class="tc-footer"><a href="termsandconditions.php" >Terms & Conditions</a></p>
          <p class="m-0 text-center text-white">Copyright &copy; ArtSource 2018</p>
          
      </div>
      <!-- /.container -->
    </footer>