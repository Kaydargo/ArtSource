<?php

$dsn = "mysql:host=localhost;dbname=artsource";
$Username = "root";
$Password = "";

try {
    $db = new PDO($dsn, $Username, $Password);
    $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, FALSE);
    $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}
catch (Exception $ex) {
    $error_message = $ex->getMessage();
    echo $error_message;
    exit();
}