<link href="../css/thumbnail-gallery.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php include('database.php');

$queryUser = "SELECT type FROM users"; 
    $statement2 = $db->prepare($queryUser);
    $statement2->execute();
    $users = $statement2->fetchAll();
    $statement2->closeCursor();
?>
<!-- Navigation -->
<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top topnav">
      <div class="container">
        <a class="navbar-brand" href="index.php">ArtSource</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home
<!--                <span class="sr-only">(current)</span>-->
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="gallery.php">Gallery</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php"> Login </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="signUp.php">SignUp</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="faq.php">F.A.Q</a>
            </li>


          </ul>
                
        </div>
      </div>
    </nav>
</header>
