<html>
    <head>
        <meta charset="UTF-8">
        <title>Dastabase Error</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <link href="css/stylesheet.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
<div class="container">
<!--Page Heading -->
        <h1 class="mt-4 mb-3 text-danger">Dastabase Error</h1>
        <div class="row">

            <!-- Post Content Column -->
            <div class="col-lg-8">
        <p>There was an error connecting to the database.</p>
        <p>Check that MySQL is running.</p>
        <!--Shows an error message specific to the error which has occurred when trying to connect to the database -->
        <p>Error message: <?php echo $error_message; ?></p>
        <p>&nbsp;</p>
              
            </div>
      
</div><!-- End row -->

</div>
    </body>
</html>