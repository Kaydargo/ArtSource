<?php
require('includes/database.php');

?>
<html>
    <head>
        <title>Add Image</title>
        <?php include_once'includes/headlinks.php';?>
      <?php include_once'includes/font.php';?>
    </head>
<?php include ('includes/header.php');?>
<!--Page Heading -->
<div class="backset">
    <main>
        
        <h1 class="mt-4 mb-3" id="add-img-header">Add Images</h1>
        <div class="image-upload-container">
        <div class="row">

            <!-- Post Content Column -->
            <div class="col-lg-8">
        <form action="addImage.php" method="post" id="addImage">
          <div class="form-group">

              <label> Select Image to upload: </label><br>
              <input type="file" name="image" id="image"><br><br>

              <label>Title:</label>
            <input type="input" name="title" class="form-control" aria-describedby="addDescription" placeholder="Add image description">
            <br>
            
            
            <label>Description:</label>
            <input type="input" name="description" class="form-control" aria-describedby="addDescription" placeholder="Add image description">
            <br>
            
            <label>Image Tag:</label><br>
          <select name="tag">
	  <option value="">Select...</option>
	  <option value=digital">Digital</option>
	  <option value="colour">Colour</option>
           <option value="paint">Paint</option>
           <option value="pencil">Pencil</option>
          </select><br><br>
            
            <label>NSFW:</label>
            <input type="radio" name="nsfw" value="Yes">Yes<br>
                <input type="radio" name="nsfw" value="No">No<br>
            <br>

            <label>&nbsp;</label>
            <button type="submit" value="Add Image" class="add-img-submit">Submit</button>
            <br>
            </div>
        </form>
               
            </div>
     
</div><!-- End row -->
        </div>
          
</main>
</div>
<?php
include 'includes/footer.php';
?>

</body>
</html>
            