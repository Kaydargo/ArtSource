<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Login</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/thumbnail-gallery.css" rel="stylesheet">
    <?php include_once'includes/headlinks.php';?>
</head>
<body>

    <?php
                session_start();
          require_once('includes/database.php');
  require_once('includes/header.php');

include("loginServer.php"); // Includes Login Script

if(isset($_SESSION['username'])){
    header("location: homeProfile.php");
}
?>
    
<div class="login"><br>
<h1 align="center">Login</h1><hr class="divline">
<br>
<div class="login-container">
<form action="" method="post" style="text-align:center;">
<input type="text" placeholder="Username or E mail" id="username" name="username"><br/><br/>
<input type="password" placeholder="Password" id="password" name="password"><br/><br/>
<input type="submit" value="Login" name="submit">
</div>
<br><br>
 <label class="signup-banner">Don't have account yet? <a href="signUp.php">Sign Up</a></label><br></br>
 

</div>
    <br><br><br><br>
<!-- Error Message -->
<span><?php echo $error; ?></span>

</body>
<?php include 'includes/footer.php'; ?>
</html>