<!DOCTYPE html>

<head>
      <title>Admin</title>
<?php include_once('includes/headlinks.php'); ?>
</head>



<body>


    <?php
                   session_start();
          require_once('includes/database.php');
          require_once('includes/header.php');

    
    $queryUser = "SELECT * FROM users WHERE userID = userID"; 
    $statement2 = $db->prepare($queryUser);
    $statement2->execute();
    $users = $statement2->fetchAll();
    $statement2->closeCursor();
     ?>

    <br>
    <div class="container">
    <div class="admin-edit-content">
 <h3 >Showing All Users</h3>
 <table class="user-table">
 <tr>
 <th scope="col">UserID</th>
 <th scope="col">Username</th>
 <th scope="col">Firstname</th>
 <th scope="col">Surname</th>
 <th scope="col">E-mail</th>
 <th scope="col">Address</th>
 <th scope="col">Type</th>
 <th scope="col">D.O.B</th>
 <th scope="col">Creation Date</th> 
  <th scope="col"></th> 
 </tr>
 
 
 
<?php foreach ($users as $user) : ?> 
 <tr>
     <td><?php echo $user['userID']; ?></td>
     <td><?php echo $user['username']; ?></td>
     <td><?php echo $user['firstname']; ?></td>
     <td><?php echo $user['lastname']; ?></td>
     <td><?php echo $user['email']; ?></td>
     <td><?php echo $user['location']; ?></td>
     <td><?php echo $user['type']; ?></td>
     <td><?php echo $user['dob']; ?></td>
     <td><?php echo $user['accountCreation']; ?></td>
     <td><a href="editProfileForm.php?userID=<?php echo $user['userID']; ?>"><button class="view-user-button">Edit</button></a></td>
     <td><a href="deleteUser?userID=<?php echo $user['userID']; ?>"><button class="view-user-button"> Delete</button></a></td>     
 </tr>
 
 <?php endforeach; ?>
 
 
 

 <th scope="col" colspan="5" align="right">
 <div class="btn-group">
 <a href="signUp.php"><button class="btn">Insert New Data</button></a>
 </div>
 </th>

 </table>

    </div>
    </div>
    <br>
    
<?php include_once 'includes/footer.php'; ?>
</body>
</html>











