<?php

require_once 'includes/database.php';
$error = ''; //Variable to Store error message;
if (isset($_POST['submit'])) {

    if (empty($_POST['username']) || empty($_POST['password'])) {
        $error = "Username or Password has not been entered";
    } else {
        //Define $user and $pass
//        $username = $_POST['username'];
//        $email = $_POST['username'];
//        $password = $_POST['password'];
        
        $username = filter_input(INPUT_POST, 'username');
        $email = filter_input(INPUT_POST, 'email');
        $password = filter_input(INPUT_POST, 'password');

        session_destroy();
        session_start();
        // Storing Session
        //sql query to fetch information of username/user email and password
// SQL Query To Fetch Complete Information Of User
        $query = "SELECT * FROM users WHERE '$username' IN (username, email) AND password='$password'";
        $statement = $db->prepare($query);
        $statement->execute();
        $rows = $statement->rowCount();
        $result = $statement->fetch();
        echo $rows;
        print_r($result);

        if ($rows === 1) {
//             $_SESSION['userID'] = $userID;
            $_SESSION['username'] = $username;

            $_SESSION['userID'] = $result["userID"];
             $_SESSION['loggedin'] = true;
            header("Location: homeProfile.php"); // Redirecting to other page
        }
        
        
        else {
            $error = "Username or Password is Invalid";
            session_destroy();
        }
    }
}

